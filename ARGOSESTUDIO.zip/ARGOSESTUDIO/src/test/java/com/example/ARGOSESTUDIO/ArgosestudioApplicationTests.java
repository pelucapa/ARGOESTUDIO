package com.example.ARGOSESTUDIO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArgosestudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
