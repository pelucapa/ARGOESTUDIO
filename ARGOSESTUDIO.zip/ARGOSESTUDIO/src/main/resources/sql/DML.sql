INSERT INTO artista (nombre, apellido, sexo, edad, telefono, mail) VALUES
('Juan', 'Dias', 'masculino', 18, 1143531023, 'juan.d@gmail.com'),
('Laura', 'Perez', 'femenino', 23, 1125247724, 'laura.perez@gmail.com'),
('Diego', 'Alvarez', 'masculino', 22, 1143531055, 'diego.a@gmail.com'),
('Daniela', 'Rios', 'femenino', 32, 1125247434, 'daniela.r@gmail.com'),
('Hernan', 'Caceres', 'masculino', 15, 1143535768, 'hernan.c@gmail.com'),
('Maria', 'Muñoz', 'femenino', 29, 1125245564, 'maria.mu@gmail.com');



INSERT INTO casting (nombre, tipo, fecha,estado, idArtista) VALUES
('Coca Cola', 'publicidad', 30/01/20123,'anotado', 1 ),
('Mama Mia', 'corto', 30/02/20123,'realizado',2 ),
('El Guazon', 'pelicula', 25/01/20123,'anotado',3 ),
('Pons', 'publicidad', 10/03/20123,'realizado', 4 ),
('Frigor', 'corto', 10/01/20123,'anotado', 5 ),
('Rocky', 'pelicula', 24/04/20123, 'realizado',6 );

INSERT INTO rodaje (nombre, tipo, fecha,estado, idArtista) VALUES
('Coca Coca', 'publicidad', 30/01/20124,'anotado',1 ),
('Mama Mia', 'corto', 30/02/20124, 'realizado',2 ),
('El Guazon', 'pelicula', 25/01/20124,'anotado', 3 ),
('Pons', 'publicidad', 10/03/20124,'realizado',4 ),
('Frigor', 'corto', 10/01/20124, 'anotado',5 ),
('Rocky', 'pelicula', 24/04/20124, 'realizado',6 );
