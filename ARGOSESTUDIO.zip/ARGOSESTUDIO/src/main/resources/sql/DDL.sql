drop database if exists cortometraje;
create database cortometraje;
use cortometraje;

create table artista(
id int auto_increment primary key,
nombre varchar (20) not null,
apellido varchar (20) not null,
sexo enum ('masculino', 'femenino'),
edad int,
telefono int,
mail varchar (20) not null
);

create table casting(
id int auto_increment primary key,
nombre varchar (20),
tipo enum ('publicidad', 'corto','pelicula'),
fecha date,
estado enum('anotado,realizado'),
idArtista int not null,
constraint fk_artista_casting
foreign key(idartista)
references artista(id)
);

create table rodaje(
id int auto_increment primary key,
nombre varchar (20),
tipo enum ('publicidad', 'corto','pelicula'),
fecha date,
estado enum('anotado,realizado'),
idArtista int not null,
constraint fk_artista_rodaje
foreign key(idArtista)
references artista(id)
);



