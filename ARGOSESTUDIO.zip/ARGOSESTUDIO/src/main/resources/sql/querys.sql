-- 1) obtener todos los casting realizados
SELECT * FROM casting WHERE estado = 'realizado';

SELECT a.nombre, a.apellido AS nombre_artista
FROM artista a
INNER JOIN casting m ON a.idArtista = m.id;

-- 2) Obtener el número de artista con casting realizado 
SELECT estado, COUNT(*) AS cantidad
FROM casting
WHERE estado = 'realizado'
GROUP BY estado;




-- 4) Obtener el nombre y apellido de los artista que realizaron el casting
SELECT a.nombre, a.apellido
FROM artista a
INNER JOIN casting m ON a.idArtista = m.id
WHERE estado = 'realizado' ;

